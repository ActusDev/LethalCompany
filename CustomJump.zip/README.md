# CustomJumpMod for Lethal Company

A simple mod that allows configurable jumps (double jump, triple jump, etc.) in **Lethal Company**.

## Features
- **Configurable Jumps**: Set the number of air jumps (e.g., 1 for double jump, 2 for triple jump, etc.) through the mod's configuration file.

## Configuration

The mod can be configured by editing the `com.actus.lethalcompany.customjump` config stored in `BepInEx/config`.
**Note**: Only the host's configuration will be applied in the lobby!

### **maxNumberOfAirJumps**
- Controls the number of air jumps.
- Example: `maxNumberOfAirJumps = 2` will enable a triple jump (1 ground jump + 2 air jumps).
- **Default value**: `1` (double jump).

### **fallValue**
- Determines how far the player can fall while still being able to air jump.
- A **higher** value (e.g., `-10f`) means you can fall **less** before air jumping.
- A **lower** value (e.g., `-20f`) allows you to fall **more** before air jumping.
- **Note**: If your fall value drops below `-35f`, you will take fall damage upon landing.
- **Default value**: `-15f`.

### **alwaysAllowJumpsWhenFalling**
- If set to `true`, the `fallValue` setting is ignored, allowing jumps at any fall distance.
- If set to `false`, the ability to air jump is restricted based on `fallValue`.
- **Default value**: `false`.

### **jumpPercentage**
- Sets the percentage chance that an air jump is executed.
- Valid values range from **0** to **100**:
    - **0** means **no air jump** will ever be executed.
    - **100** means the air jump will **always** be executed.
    - Values between **1 and 99** determine the **probability** of an air jump happening (e.g., 50 means there's a 50% chance).
- **Default value**: `50`.

### jumpCooldown

- Controls the delay between consecutive air jumps.
- **Default Value**: `2.5`
- **Note**: To allow spamming jumps, set the cooldown to `0`.


## Credits
- **Author**: ActusDev
- **Special Thanks** to Leopard_V for designing the thumbnail.

## Links
- [GitHub Repository](https://github.com/ActusDev/LethalCompany)

---

Enjoy jumping to new heights in Lethal Company!