## 1.0.4
- Fixed an issue where, on the first check, the server (which isn't the owner of the apparatus) would incorrectly ask if the apparatus should explode for another player holding it.
- Unnecessary RPC registrations were removed to prevent redundant calls and improve network efficiency.

## 1.0.3
- Fixed a synchronization issue where the server and client were not always properly aligned, causing explosions to sometimes not appear and the apparatus to remain on the ground when it should have been removed.
- Fixed an issue with lobby transitions, ensuring proper functionality during network object spawning and preventing null reference errors.
- Updated the apparatus value range to be between `50` and `200`, down from `50` to `250`, and increased the explosion chance when dropped to `10%`, up from the previous `5%`.

## 1.0.2
- Added a new feature that adjusts the apparatus's scrap value from a fixed `80` to a dynamic range between `50` and `250`.
- Fixed a HUD issue where the scrap value was not displayed even after bringing it to the ship.

## 1.0.1
- Fixed the bug that caused the apparatus to explode every time.

## 1.0.0
- Initial release of Radiation Leak!
- A bug caused the apparatus to explode consistently at full probability.

---