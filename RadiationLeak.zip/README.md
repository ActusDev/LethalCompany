# Radiation Leak for Lethal Company

A mod that refines the current apparatus by adding new features, including damage when held and a chance to explode when dropped.

## Features
- **Lethal Holding**: The apparatus now deals damage to the player while held. 
- **Explosion on Drop**: When dropped, the apparatus has a 5% chance of exploding and killing the player. You are safe on the ship though, as the apparatus cannot explode there!
- **Time Limit**: If the player is at full health, they can hold the apparatus for up to 3 minutes before dying.

## Credits
- **Author**: ActusDev

## Links
- [GitHub Repository](https://github.com/ActusDev/LethalCompany)

---

Handle the apparatus with care, or face the consequences in Lethal Company!