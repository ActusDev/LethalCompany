## 1.0.0
- Initial release of `Echoes of Jeb`!

---