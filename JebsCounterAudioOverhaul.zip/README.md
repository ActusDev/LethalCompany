# Jebs Counter Audio Overhaul for Lethal Company

A simple mod that allows you to change the audio of the door sound of Jeb's Counter in **Lethal Company**.

## Features
- **Customizable Door Sound**: Randomly selects a sound from your files and replaces the door sound in Jeb's Counter.
- **Easily Add New Sounds**: Place `MP3` or `WAV` files in the `Sounds` folder for further customization.

## Getting Started

- On the **first boot** of the mod, the `Sounds` folder will be automatically generated for you.
- Once the folder is created, you can add your own MP3 or WAV files into the `Sounds` folder to customize the door sound.
- The mod will randomly choose a sound from the files in the `Sounds` folder and play it each time the door sound is triggered in Jeb's Counter.

## Credits
- **Author**: ActusDev
- **Special Thanks** to Leopard_V for designing the thumbnail.

## Links
- [GitHub Repository](https://github.com/ActusDev/LethalCompany)

---

Enjoy customizing your Jebs Counter experience in Lethal Company!