## 1.0.0
- Initial release of `Pajama Man Unleashed`!

---