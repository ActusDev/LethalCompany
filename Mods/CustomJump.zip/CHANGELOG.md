## 1.0.3
- Fixed an issue with lobby transitions, ensuring proper functionality during network object spawning and preventing null reference errors.
- Jump behavior is now only handled by the player's owner, preventing unintended jump logic execution on non-owned clients. 
- Increased the default jumpPercentage from `50` to `100`.

## 1.0.2
- The configuration now syncs across all clients, ensuring the host's settings are enforced. 
- Prevents clients from using their own custom configurations, making air jumps fair for everyone.

## 1.0.1
- Added `fallValue` (`-15f`) to control how far the player can fall before air jumping.
- Added `alwaysAllowJumpsWhenFalling` (`false`) to let players jump at any fall distance if enabled.
- Added `jumpPercentage` (`50`) to set the probability of executing an air jump.
- Added `jumpCooldown` (`2.5f`) to control the delay between consecutive air jumps.

## 1.0.0
- Initial release of Custom Jump!
- Added configuration option for `maxNumberOfAirJumps`, allowing users to customize the number of air jumps.

---